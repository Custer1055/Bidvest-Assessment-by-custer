<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.1.0
    </div>
    <strong>Student Management &nbsp;<a href="https://api.whatsapp.com/send?phone=+254708344101">Developed By Ronald Ngoda contact +254708344101</a>.</strong> All rights
    reserved.
  </footer>